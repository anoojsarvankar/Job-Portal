<?php
include('../Myconnect.php');
session_start();
$sid=$_SESSION['sid'];
if($_GET['type']=='degree')
{
    if(isset($_POST['submit']))
    {
        $course=$_POST['course'];
        $query="update jobseeker set qualification='$course' where sid=$sid";
        if(!mysqli_query($conn,$query))
        {
            header('location:profile.php?errormsg=failedquery');
        }
        else
        {
            header('location:profile.php?errormsg=successquery');
        }
    }
}
else if($_GET['type']=='name')
{
    if(isset($_POST['submit']))
    {
        $newfname=$_POST['newfname'];
        $newlname=$_POST['newlname'];
        $query="update jobseeker set fname='$newfname',lname='$newlname' where sid=$sid";
        if(!mysqli_query($conn,$query))
        {
            header('location:profile.php?errormsg=failedquery');
        }
        else
        {
            header('location:profile.php?errormsg=successquery');
        }
    }
}

?>