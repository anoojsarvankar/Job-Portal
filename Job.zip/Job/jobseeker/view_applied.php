<?php
session_start();
$sid=$_SESSION['sid'];
include('../Myconnect.php');
$q1=mysqli_query($conn,"select * from application where sid=$sid");
?>
<!DOCTYPE HTML>
<html>
<head>
    <title>View Applied Jobs</title>
</head>
<div id="nav">
    <nav>
        <div class="navbar" id="insidenav">
            <div class="navbar-header">
                <a class="navbar-brand" href="#">Job Portal</a>
            </div>
            <ul class="nav navbar-nav">
                <li ><a href="profile.php"><?php echo "$_SESSION[fname]"; ?><span class="sr-only">(current)</span></a></li>
                <li class="active"><a href="#"> View Applied Job </a></li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Options<span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="#">Update Profile</a></li>
                        <li><a href="#">View Applied Jobs</a></li>
                        <li role="separator" class="divider"></li>
                        <li><a href="view_selected.php">View Selected Jobs</a></li>
                    </ul>
                </li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Account<span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="#">Account Overview</a></li>
                        <li role="separator" class="divider"></li>
                        <li><a href="#">Account Settings</a></li>

                    </ul>
                </li>
                <li><a href="../logout.php">Logout</a></li>
            </ul>
        </div><!-- /.navbar-collapse -->
    </nav>
</div><!-- /.container-fluid -->

<body>
<div class="container">
    <h3 class="text-center" style="margin-top: 50px; color: #265a88">You Applied for these jobs</h3>
    <div class='page-header' style='background:skyblue'></div>
     <?php if(mysqli_num_rows($q1)>0) { ?>
        <?php
        while($row=mysqli_fetch_array($q1)) {
			$i=1;
            $aid=$row['aid'];
            $q2=mysqli_query($conn,"select * from ads where aid = $aid");
            while ( $result = mysqli_fetch_array($q2) ) {
                $comp=mysqli_query($conn,"select * from employer where eid = $result[eid]");
                $rowcomp=mysqli_fetch_array($comp);
               echo "<h3>[".$i."]  <a style='color: green;'  href='applicationpage.php?aid=" . $result['aid']."&eid=".$result['eid'] . "'>".$result['title']."</a></h3>"; 
               echo "<h4> Employer: <a href='view_emp.php?id=".$rowcomp['eid']."'>".$rowcomp['fname']." ".$rowcomp['lname']."</a></h4>";
               echo "<p>".$result['jobdesc']."</p>";
               echo "<h4>Job Posted on: " . $result['postdate'] ."</h4>";
               echo "<h4> Applied on: " . $row['date']."</h4>";
                
            }
            echo "<hr style='background:blue;'>";
           $i=$i+1;
        }
        ?>
</table>
    <?php } else {  echo " <div class='container'> <div class='alert alert-warning alert-dismissible' role='alert'>
            <button type='button' class='close'  data-dismiss='alert' aria-label='Close'><span
                    aria-hidden='true'>&times;</span></button>
           <p style='font-size: 20px'><strong>Note:</strong> You have'nt applied for any jobs yet!</p>
        </div> </div>";
        }
     ?>
</div>
</body>
<link rel="stylesheet" href="../bootstrap/dist/css/bootstrap.min.css">
<link href="../css/main.css" rel="stylesheet">
<link href="../css/jobseeker.css" rel="stylesheet"> 
<script src="../js/jquery-1.12.0.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
</html>
