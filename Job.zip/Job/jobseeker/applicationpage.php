<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="company.css">
  <link rel="stylesheet" href="../bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="../css/applicationpage.css">
<script src="../js/jquery-1.12.0.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
</head>
<body>
<div id="nav">
    <nav class="navbar">
        <div class="navbar" id="insidenav1">
            <div class="navbar-header">
                <a class="navbar-brand" href="../index.php">Job Portal</a>
            </div>
            <ul class="nav navbar-nav">
                <li><a href="profile.php">Profile<span class="sr-only">(current)</span></a></li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Options<span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="view_applied.php">View Applied Jobs</a></li>
                        <li role="separator" class="divider"></li>
                        <li><a href="view_selected.php">View Selected Jobs</a></li>
                    </ul>
                </li>
            </ul>
            
            <ul class="nav navbar-nav navbar-right">
                <li><a href="../logout.php">Logout</a></li>
            </ul>
        </div><!-- /.navbar-collapse -->
    </nav>
</div><!-- /.container-fluid -->           
  
<div class="container-fluid text-center">
<?php
  session_start();
    include('../Myconnect.php');
    $eid=$_GET['eid'];
    $aid=$_GET['aid'];
    $query="select * from ads where aid='$aid'";
    $result=mysqli_query($conn,$query);
    $resultset=mysqli_fetch_array($result);
    $cmpname="select companyname from employer where eid='$eid'";
    $result2=mysqli_query($conn,$cmpname);
    $result2a=mysqli_fetch_array($result2);
    echo"<div class='col-sm-12 text-left'>"; 
    echo"<div class='box'>";
    echo"<img src='../uploads/logo/".$result2a['companyname'].".jpg' class='image'></br></br>";
    echo"<table border='1' width=100%><tr><td><P>JOB TITLE:</td><td>".$resultset['title']."</p></td></tr>";
    echo"<tr><td><p>JOB DESCRIPTION:</td><td>".$resultset['jobdesc']."</p></td></tr>";
    echo"<tr><td><p>Salary:</td><td>".$resultset['salary']."</p></td></tr>";
    echo"<tr><td><p>Location:</td><td>".$resultset['location']."</p></td></tr>";
    echo"<tr><td><p>Vacancies:</td><td>".$resultset['vacno']."</p></td></tr>";
    echo"<tr><td><p>Required Qualification:</td><td>".$resultset['course']."</p></td></tr>";
    echo"<tr><td><p>Job Profile:</td><td>".$resultset['jprofile']."</p></td></tr></table></br></br>";
    echo"<p><span class='glyphicon glyphicon-map-marker'></span>".$resultset ['location']."</p>";
     echo"<a href='apply_job.php?aid=".$aid."&eid=".$eid."'>APPLY FOR THIS JOB!</a>";
     echo"</div>"; 
     echo" </a>";
     ?>
   
  </div>
</div>

<footer class="container-fluid text-center">
        <a href="#insidenav1" title="To Top">
            <span class="glyphicon glyphicon-chevron-up"></span>
        </a>
        <p id="f1">Job Portal</p>
    </footer>

</body>
</html>
