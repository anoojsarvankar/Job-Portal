<?php
session_start();
include('../Myconnect.php');
$q = mysqli_query($conn,"select * from jobseeker WHERE sid = $_GET[jsid]");
$row=mysqli_fetch_array($q);
?>
<!DOCTYPE HTML>
<html>
<head>
    <title>View Jobseeker</title>
    <link rel="stylesheet" href="../bootstrap/dist/css/bootstrap.min.css">
    <link href="../css/main.css" rel="stylesheet">
    <style type="text/css">
        #insidenav{
            background: #dd4814;
            color: white;
            font-size: 13px;
        }
        nav a{
            font-size: 16px;
            font-family: ubuntu;
            color: white;
        }
        nav ul li {
            font-size: 16px;
            font-family: ubuntu;
        }
        nav ul li.active{
            background: whitesmoke;
        }
        nav ul li.active a{
            color:#dd4814;;
        }
        table.table{
            background: transparent;
        }
        td.tbold{
            font-weight: bold;
        }
        table{
            background: transparent;
        }
        #viewmain{
            margin-top: 30px;
        }
        span.badge{
            background: white;
            color: black;
        }   
    </style>
            <?php
            if(isset($_POST['submit'])){ 
                $jsid=$_GET['jsid'];
                $aid=$_GET['aid'];
                $q2="update application set selection=1 where sid=$jsid and aid=$aid";
                $resultselect=mysqli_query($conn,$q2);
            }
            ?>   
</head>
<div id="nav">
    <nav>
        <div class="navbar" id="insidenav">
            <div class="navbar-header">
                <a class="navbar-brand" href="#">Job Portal</a>
            </div>

            <ul class="nav navbar-nav">
                <li><a href="profile.php"><?php echo $_SESSION['fname']; ?><span class="sr-only">(current)</span></a></li>
                <li class="active"><a href="#">View Jobseeker Profile</a></li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Menu<span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="post_jobs.php">Post New Jobs</a></li>
                        <li><a href="managejobs.php">Manage Jobs</a></li>
                        <li role="separator" class="divider"></li>
                        <?php echo"<li><a href='manage_applicants.php?jobid=".$_GET['aid']."'>Manage Applicants</a></li>";?>
                    </ul>
                </li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Account<span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="#">Account Overview</a></li>
                        <li><a href="#">Account Settings</a></li>
                        <li role="separator" class="divider"></li>
                        <li><a href="#">Edit Profile</a></li>
                    </ul>
                </li>
                <li><a href="../logout.php">Logout</a></li>
            </ul>
        </div><!-- /.navbar-collapse -->
    </nav>
</div><!-- /.container-fluid -->
<body>
<div class="container-fluid" id="content">
<!-- ---------------------------------------------- nav ends ----------------------------------------------------------------------------->

    <aside class="col-sm-3" role="complementary">
        <div class="region region-sidebar-first well" id="sidebar">
            <h3 style="color: #009999" class="text-center" > Profile:<?php echo " ".$row['fname']; ?> </h3>
        </div>

        <!-- profile pic -->
   
    <div class="text-center">
        <div class="img">
           <?php if($row['status']!=0) {
              echo "<img src = '../uploads/images/".$row['sid'].".jpg"."'>";
             }else echo" <img src='../images/user_fallback.png'>";
           ?>
        </div>
         <strong><?php echo $row['fname'].' '.$row['lname']; ?> </strong>

            <p> <?php if($row['resume']!="") {
                    echo "<button type='button' class='btn bg-primary' ><a href = '../uploads/resume/".$row['resume'].".pdf"."' style='color:white;' >
                    Download Resume File </a ></button>";
                }?>
                <!-- profile pic --->
    </aside>

    <div class="col-sm-7">
        <div id="details"  style="margin-top: 50px;">
            <h3> User Details:</h3>
            <table class="table" >
                <tr >
                    <td class="tbold">Full Name:</td>
                    <td><?php echo $row['fname'].' '.$row['lname']; ?></td>

                </tr>
                <tr>
                    <td class="tbold">Email:</td>
                    <td><?php echo $row['email']; ?></td>
                </tr>
                <tr>
                    <td class="tbold">Phone:</td>
                    <td><?php echo $row['phone']; ?></td>
                </tr>
                <tr>
                    <td class="tbold">Location:</td>
                    <td><?php echo $row['location']; ?></td>
                </tr>
                <tr>
                    <td class="tbold">Qualification:</td>
                    <td><?php echo $row['qualification']; ?></td>
                </tr>
            </table>
            <?php
            $q3="select * from application where aid=$_GET[aid] and sid=$_GET[jsid]";
            $checkselection=mysqli_query($conn,$q3);
            $csarray=mysqli_fetch_array($checkselection);
            if($csarray['selection']==0){
                echo"<form method='post'><button type='submit' name='submit' class='btn btn-success'>Select Candidate</button></form>";
            }
            else
               echo"<button type='button' class='btn btn-success'>Already selected Candidate</button>";
            ?>
        </div> <!-- profile -->

    </div>
</div>

</body>
<link rel="stylesheet" href="../bootstrap/dist/css/bootstrap.min.css">
<script src="../js/jquery-1.12.0.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
</html>
