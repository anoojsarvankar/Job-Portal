-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 23, 2019 at 08:54 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.1.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jobportal`
--

-- --------------------------------------------------------

--
-- Table structure for table `ads`
--

CREATE TABLE `ads` (
  `aid` int(11) NOT NULL,
  `eid` int(11) DEFAULT NULL,
  `title` varchar(20) DEFAULT NULL,
  `jobdesc` varchar(200) DEFAULT NULL,
  `salary` int(11) DEFAULT NULL,
  `location` varchar(10) DEFAULT NULL,
  `vacno` int(11) NOT NULL,
  `course` varchar(20) NOT NULL,
  `jprofile` varchar(100) NOT NULL,
  `postdate` date NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ads`
--

INSERT INTO `ads` (`aid`, `eid`, `title`, `jobdesc`, `salary`, `location`, `vacno`, `course`, `jprofile`, `postdate`, `status`) VALUES
(1, 1005, 'Android App Develope', 'Make android apps according to client re', 0, 'Thane', 1, 'B.Sc', 'Anyone who is enthusiastic and takes interest in a', '2024-09-19', 1),
(2, 1005, 'Web DEV', 'Website for college required', 0, 'Thane', 1, 'B.Sc', 'Anyone with good interest and art skills.', '2019-09-24', 1),
(3, 1005, 'Sample ad 3', 'Sample ad job description is pasted here!', 5000, 'mumbai', 2, 'B.Tech/B.E.', 'Sample job profile can be specified here!', '2019-09-24', 1),
(4, 1005, 'Samsung UI Developme', 'Sample job description is pasted here can be tuned to user preference', 20000, 'Thane', 1, 'B.Tech/B.E.', 'Anyone who has experience in UI development and android affinity can apply.', '2019-10-23', 1);

-- --------------------------------------------------------

--
-- Table structure for table `application`
--

CREATE TABLE `application` (
  `appid` int(11) NOT NULL,
  `aid` int(11) NOT NULL,
  `eid` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `date` date NOT NULL,
  `selection` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `application`
--

INSERT INTO `application` (`appid`, `aid`, `eid`, `sid`, `date`, `selection`) VALUES
(10, 1, 1005, 10, '2019-09-24', 0),
(11, 3, 1005, 10, '2019-09-24', 1);

-- --------------------------------------------------------

--
-- Table structure for table `employer`
--

CREATE TABLE `employer` (
  `eid` int(11) NOT NULL,
  `email` varchar(20) NOT NULL,
  `fname` varchar(10) DEFAULT NULL,
  `lname` varchar(10) DEFAULT NULL,
  `companyname` varchar(20) NOT NULL,
  `phone` int(11) NOT NULL,
  `address` varchar(100) NOT NULL,
  `about` varchar(100) NOT NULL,
  `location` varchar(10) DEFAULT NULL,
  `pincode` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `logo` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employer`
--

INSERT INTO `employer` (`eid`, `email`, `fname`, `lname`, `companyname`, `phone`, `address`, `about`, `location`, `pincode`, `status`, `logo`) VALUES
(1005, 'jash@gmail.com', 'Jash', 'Vora', 'TCS', 1000000001, 'Hiranandani,Thane', 'IT company under Tata Group providing consultancies and software solutions.', 'Thane', 400615, 1, 0),
(1006, 'Ronakjain420@gmail.c', 'Ronak', 'Jain', 'Bangar Wala', 2147483647, '101, Sky Apt. Motivilla road.Thane(E)', 'Very good in his work', 'Thane', 400603, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `jobseeker`
--

CREATE TABLE `jobseeker` (
  `email` varchar(20) DEFAULT NULL,
  `sid` int(11) NOT NULL,
  `fname` varchar(20) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `phone` int(11) NOT NULL,
  `qualification` varchar(10) NOT NULL,
  `location` varchar(20) NOT NULL,
  `resume` int(11) DEFAULT 0,
  `status` int(11) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jobseeker`
--

INSERT INTO `jobseeker` (`email`, `sid`, `fname`, `lname`, `phone`, `qualification`, `location`, `resume`, `status`) VALUES
('anooj21m@gmail.com', 10, 'Anooj', 'Sarvankar', 1000000000, 'B.Tech/B.E', 'Thane', 10, 1),
('deepak@gmail.com', 12, 'Deepak', 'Yadav', 2147483647, 'B.Tech/B.E', 'Mumbai', 0, 1),
('gaurav@gmail.com', 14, 'Gaurav', 'Samant', 2147483647, 'M.Tech/M.E', 'Thane', 0, 1),
('xyz@gmail.com', 16, 'xyz', 'abc', 2147483647, 'B.Sc', 'Thane', 0, 1),
('xyz@gmail.com', 17, 'xyz', 'abc', 2147483647, 'B.Sc', 'Thane', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `email` varchar(20) NOT NULL,
  `password` varchar(20) DEFAULT NULL,
  `type` varchar(10) DEFAULT NULL,
  `status` int(11) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`email`, `password`, `type`, `status`) VALUES
('anooj21m@gmail.com', '123', 'jobseeker', 1),
('deepak@gmail.com', '123', 'jobseeker', 1),
('gaurav@gmail.com', '123', 'jobseeker', 1),
('jash@gmail.com', '123', 'employer', 1),
('Ronakjain420@gmail.c', '123', 'employer', 0),
('xyz@gmail.com', '123', 'jobseeker', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ads`
--
ALTER TABLE `ads`
  ADD PRIMARY KEY (`aid`),
  ADD KEY `eid` (`eid`);

--
-- Indexes for table `application`
--
ALTER TABLE `application`
  ADD PRIMARY KEY (`appid`),
  ADD KEY `application_ibfk_1` (`aid`),
  ADD KEY `application_ibfk_2` (`eid`),
  ADD KEY `application_ibfk_3` (`sid`);

--
-- Indexes for table `employer`
--
ALTER TABLE `employer`
  ADD PRIMARY KEY (`eid`),
  ADD UNIQUE KEY `companyname` (`companyname`),
  ADD KEY `employer_ibfk_1` (`email`);

--
-- Indexes for table `jobseeker`
--
ALTER TABLE `jobseeker`
  ADD PRIMARY KEY (`sid`),
  ADD KEY `jobseeker_ibfk_1` (`email`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ads`
--
ALTER TABLE `ads`
  MODIFY `aid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `application`
--
ALTER TABLE `application`
  MODIFY `appid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `employer`
--
ALTER TABLE `employer`
  MODIFY `eid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1007;

--
-- AUTO_INCREMENT for table `jobseeker`
--
ALTER TABLE `jobseeker`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ads`
--
ALTER TABLE `ads`
  ADD CONSTRAINT `ads_ibfk_1` FOREIGN KEY (`eid`) REFERENCES `employer` (`eid`);

--
-- Constraints for table `application`
--
ALTER TABLE `application`
  ADD CONSTRAINT `application_ibfk_1` FOREIGN KEY (`aid`) REFERENCES `ads` (`aid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `application_ibfk_2` FOREIGN KEY (`eid`) REFERENCES `employer` (`eid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `application_ibfk_3` FOREIGN KEY (`sid`) REFERENCES `jobseeker` (`sid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `employer`
--
ALTER TABLE `employer`
  ADD CONSTRAINT `employer_ibfk_1` FOREIGN KEY (`email`) REFERENCES `user` (`email`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `jobseeker`
--
ALTER TABLE `jobseeker`
  ADD CONSTRAINT `jobseeker_ibfk_1` FOREIGN KEY (`email`) REFERENCES `user` (`email`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `jobseeker_ibfk_2` FOREIGN KEY (`email`) REFERENCES `user` (`email`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
